# model简介  

## 第三部分 —— 非门  

+ 过程：insulin浓度过高触发非门逻辑，激活miRNA启动子，转录出miRNA,miRNA靶向降解Gal4mRNA  
+ 重点：insulin需要达到一个阈值，miRNA靶向降解Gal4mRNA  
+ 仪表盘：insulin、miRNA、Gal4mRNA  
